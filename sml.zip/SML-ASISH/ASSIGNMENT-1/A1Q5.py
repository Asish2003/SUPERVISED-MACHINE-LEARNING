def find_GCD(a,b):
    while b:
        a,b = b,a%b
    return a 
num1 = int(input('Enter the first number:'))
num2 = int(input('Enter the second number:'))
gcd_result=find_GCD(num1,num2)
print(gcd_result)