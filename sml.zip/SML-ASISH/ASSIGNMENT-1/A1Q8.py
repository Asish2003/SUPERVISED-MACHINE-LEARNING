def is_divisible_by_9(n):
   
    sum_of_digits = 0

   
    while n > 0:
       
        digit = n % 10

      
        sum_of_digits += digit

      
        n = n // 10

   
    if sum_of_digits % 9 == 0:
        return True
    else:
        return False
num = 333
if is_divisible_by_9(num):
    print(num, "is divisible by 9")
else:
    print(num, "is not divisible by 9")