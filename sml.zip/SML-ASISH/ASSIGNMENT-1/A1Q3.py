marks = int(input("Enter the marks"))
if marks>=70:
    remarks = 'good'
else:
    remarks = 'average'
print(remarks)