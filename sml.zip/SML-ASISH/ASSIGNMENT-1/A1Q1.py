print ("Evaluate expressions: ")
a1=-7*20+8/16*2+54
print(a1)
a2=7**2//9%3
print(a2)
a3=(7-4*2)*10-25*8//5
print(a3)
a4=5%10+10-25*8//5
print(a4)