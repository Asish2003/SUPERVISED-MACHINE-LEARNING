import random
val=random.randint(0,1000)
print(val)
digit=0
while(val!=0):
    digit+=val%10
    val//=10

print(digit)