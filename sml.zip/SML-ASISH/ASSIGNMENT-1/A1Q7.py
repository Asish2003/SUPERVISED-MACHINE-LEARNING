def find_max(lst):
    max_elem = lst[0]
    for elem in lst[1:]:
        if elem > max_elem:
            max_elem = elem
    return max_elem

print(find_max([10, 20, 30, 40, 50]))  