list1=[1,2,3,4,5,6,7,8]
sum=0
for i in list1:
    sum=sum+i
print('The sum of all elements of the list: ', sum)