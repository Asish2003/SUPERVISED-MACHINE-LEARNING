from scipy.special import comb

# Total number of students
total_students = 8

# Number of members in the committee
committee_size = 3

# Calculate the total number of possible committees
total_committees = comb(total_students, committee_size)

print("Total number of possible committees:", int(total_committees))
