import matplotlib.pyplot as plt

# Monthly sales data
monthly_sales = [50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105]

# Months from 1 to 12
months = list(range(1, 13))

# Create a line plot
plt.plot(months, monthly_sales, marker='o', linestyle='-')

# Add labels and title
plt.xlabel('Month')
plt.ylabel('Monthly Sales (in thousands of dollars)')
plt.title('Monthly Sales Trend Over the Past Year')

# Save the image
plt.savefig('monthly_sales_trend.png')

# Show the plot
plt.show()
