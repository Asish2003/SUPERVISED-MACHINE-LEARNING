import numpy as np

scores = [
    [80, 90, 70, 85, 95],
    [75, 85, 95, 70, 80],
    [85, 95, 75, 80, 90],
    [90, 80, 85, 75, 70]
]

# Convert the scores list into a NumPy array
scores_array = np.array(scores)

# A. Calculate the average score for each subject
average_scores_subjects = np.mean(scores_array, axis=0)
print("Average scores for each subject:", average_scores_subjects)

# B. Determine which student has the highest average score across all subjects
average_scores_students = np.mean(scores_array, axis=1)
highest_average_student_index = np.argmax(average_scores_students)
print("Student with the highest average score:", highest_average_student_index + 1)

# C. Find the subject in which the highest-scoring student has scored the lowest
highest_scoring_student_index = np.argmax(scores_array[highest_average_student_index])
lowest_score_subject_index = np.argmin(scores_array[:, highest_scoring_student_index])
print("Subject in which the highest-scoring student has scored the lowest:", lowest_score_subject_index + 1)
