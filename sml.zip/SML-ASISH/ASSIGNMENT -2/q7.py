import numpy as np
from scipy.linalg import det, inv

# Define the matrix A
A = np.array([[3, 2, -1],
              [2, -4, 7],
              [1, 1, 1]])

# Calculate the determinant of A
determinant_A = det(A)

# Calculate the inverse of A
inverse_A = inv(A)

print("Determinant of matrix A:", determinant_A)
print("\nInverse of matrix A:\n", inverse_A)
