import matplotlib.pyplot as plt

# Given dataset
students = ['Alice', 'Bob', 'Charlie', 'David', 'Emily']
SML_scores = [85, 90, 70, 80, 75]
AD_scores = [80, 75, 85, 70, 90]

# A. Create a bar graph showing the SML scores of each student
plt.figure(figsize=(8, 5))
plt.bar(students, SML_scores, color='red')
plt.xlabel('Students')
plt.ylabel('SML Scores')
plt.title('SML Scores of Students')
plt.show()

# B. Create a histogram showing the distribution of AD scores
plt.figure(figsize=(8, 5))
plt.hist(AD_scores, bins=10, color='lightgreen', edgecolor='green')
plt.xlabel('AD Scores')
plt.ylabel('Frequency')
plt.title('Distribution of AD Scores')
plt.show()

# C. Create a scatter plot to visualize the relationship between SML and AD scores
plt.figure(figsize=(8, 5))
plt.scatter(SML_scores, AD_scores, color='orange')
plt.xlabel('SML Scores')
plt.ylabel('AD Scores')
plt.title('Relationship between SML and AD Scores')
plt.show()

# D. Create a pie chart to represent the distribution of scores across students
plt.figure(figsize=(8, 8))
plt.pie(SML_scores, labels=students, autopct='%1.1f%%', startangle=140)
plt.title('Distribution of SML Scores Across Students')
plt.show()
