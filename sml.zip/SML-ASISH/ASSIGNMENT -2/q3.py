
import pandas as pd
data1 = pd.read_csv("person_details.csv")
#Q(a)
print(data1.iloc[0:3,0:2])
#Q(b)
print(data1.loc[data1['Living Expenses']>3500])
#Q(C)
print(data1.loc[(data1['Gender']=='Female')&(data1["City"].isin(["New York","Los Angeles"]))])
#Q(d)
print(data1.iloc[2:8])
                       