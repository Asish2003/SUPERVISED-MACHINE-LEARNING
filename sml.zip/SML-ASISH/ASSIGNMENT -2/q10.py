import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# Given dataset
data = {
    'Month': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    'Sales_Revenue': [50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105]
}

# Convert data to a pandas DataFrame
df = pd.DataFrame(data)

# Create a line plot using Seaborn
plt.figure(figsize=(10, 6))
sns.lineplot(x='Month', y='Sales_Revenue', data=df, marker='o', color='skyblue')
plt.xlabel('Month')
plt.ylabel('Sales Revenue (in thousands of dollars)')
plt.title('Trend of Monthly Sales Revenue Over the Past Year')
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.tight_layout()  # Adjust layout to prevent clipping of labels
plt.show()
